export default function(){
    return[
        {
            Data:1,
          id:1,
          Name:'Инвестиционный маркетплейс',
          discsas:'Работает с 2012 года. Релиз нового интерфейса в сен-окт 2017. Инвестиционные предложения из традиционной и новой экономики: алгоритмические стратегии на NYSE, криптовалютные стратегии, IPO, ICO, OTC.',
          img:'https://static.uttoken.io/static/media/investment.855bfc88.png',  
        },
        {
            Data:2,
            id:2,
            Name:'Все криптобиржи в одной платформе',
            discsas:'С 2011 года платформа Аврора позволяет торговать на NYSE, NASDAQ, CME, MOEX и других биржах. Сейчас мы подключаем криптовалютные биржи, сервис для исполнения больших ордеров и готовим к запуску собственную биржу.',
            img:'https://static.uttoken.io/static/media/platform.f2cf745f.png',
        },
        {
            Data:3,
            id:3,
            Name:'Мегасловарь',
            discsas:'Финансовый словарь на UTMagazine.ru «взорвал» посещаемость в 25 раз. Мы собираемся повторить успех на других языках и для других аудиторий.',
            img:'https://static.uttoken.io/static/media/dictionary.593cfd48.png',
        }
    ]
}