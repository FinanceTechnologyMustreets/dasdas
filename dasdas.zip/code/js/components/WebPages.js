import React from'react';
import MenuIndex from'../index/indexMenu';
import ModelIndex from'../index/IndexModel';
 


const WebPages =() =>(
    <MenuIndex />,
    <ModelIndex />


);

export default WebPages;