import React,{ Component } from "react";


class ModelH extends Component
{
    render()
    {
        return (
            <div className="row">
            <div className="col col__small_14">
            <div className="section__head_using section__head">
            <h2 className="title title_secondary">Применение 
            <img src="https://uttoken.io/static/media/UT_semibold_black.db96b73e.svg" className="icon_token" alt="UT token">
            </img></h2></div></div>
            </div>
            );
    }
}
export default ModelH;


