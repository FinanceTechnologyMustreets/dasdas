import React,{component, Component} from 'react';
import {BindActonCreators, bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {select} from '../action/index';




class CarsList extends Component{
    showList(){
        return this.props.cars.map((car)=>{
    return (
        <div 
        key={car.id}>
        
        <li className="menu__item menu__item_main">
            <a>{car.model}</a></li>
        </div>
        
    );
        }) ;
    }

    render(){
        return(
            <div className="col col__small_13 col__small-offset-1 flex-container flex__align_center xsmall_hide">
            
            <div className="header__menu">
            <ul className="menu menu_main">
                {this.showList()}  
            </ul>
            </div>
            </div>
        );
    }
}
function mapStateToProps(state){
    return{
        cars: state.carse
    };

}

function matchDispatcheToProps(dispatch){
    return bindActionCreators({select:select},dispatch)
}

export default connect(mapStateToProps,matchDispatcheToProps)(CarsList);