export default function(){
    return[
        {
          id:1,
          model:'Инвестиционный маркетплейс',
          discsas:'Работает с 2012 года. Релиз нового интерфейса в сен-окт 2017. Инвестиционные предложения из традиционной и новой экономики: алгоритмические стратегии на NYSE, криптовалютные стратегии, IPO, ICO, OTC.',
          img:'https://static.uttoken.io/static/media/investment.855bfc88.png',  
        },
        {
            id:2,
            model:'Все криптобиржи в одной платформе',
            discsas:'С 2011 года платформа Аврора позволяет торговать на NYSE, NASDAQ, CME, MOEX и других биржах. Сейчас мы подключаем криптовалютные биржи, сервис для исполнения больших ордеров и готовим к запуску собственную биржу.',
            img:'https://static.uttoken.io/static/media/platform.f2cf745f.png',
        },
        {
            id:3,
            model:'Мегасловарь',
            discsas:'Финансовый словарь на UTMagazine.ru «взорвал» посещаемость в 25 раз. Мы собираемся повторить успех на других языках и для других аудиторий.',
            img:'https://static.uttoken.io/static/media/dictionary.593cfd48.png',
        }
    ]
}