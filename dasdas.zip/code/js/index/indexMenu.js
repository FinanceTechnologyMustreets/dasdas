import React,{component, Component} from 'react';
import CarList from '../containers/cars-list';
import Logo from '../containers/logo';





class SubIndex extends Component{
    render(){
        return(
            <div className="header__top header__top_scrolled">
            <div className="grid_container">
            <div className="row">
            <Logo />
            <CarList />
            </div>
            </div>
            </div>
        );
        
    }
}
export default SubIndex;